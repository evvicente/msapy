= MSA =

Copyright (C) 2009 Jorge Rodr�guez Ara�jo <grrodri@gmail.com>

MSA es una implementaci�n libre (GPL) del m�todo de la rigidez para la resoluci�n de estructuras planas.

== Descripci�n ==

Con este desarrollo se pretende lograr una aplicaci�n funcional que permita la resoluci�n de todo tipo de estructuras planas.

Para facilitar y agilizar el desarrollo se ha optado por la implementaci�n en Python, dado que se trata de un lenguaje sencillo, que dispone de potentes herramientas de c�lculo matricial, es multiplataforma y adem�s es libre.

== Instalaci�n ==

Dado que esta aplicaci�n se encuentra desarrollada completamente en Python, puede ser ejecutada en cualquier plataforma para la que se encuentren disponibles los paquetes Numpy y matplotlib.

Para ejecutar MSA en Windows, simplemente:
 * Instala los paquetes: [http://www.python.org/ftp/python/2.5.4/python-2.5.4.msi Python], [http://downloads.sourceforge.net/sourceforge/numpy/numpy-1.3.0-win32-superpack-python2.5.exe Numpy] y [http://downloads.sourceforge.net/sourceforge/matplotlib/matplotlib-0.98.5.3.win32-py2.5.exe matplotlib]
 * Una vez instalados los paquetes anteriores, dado que a�n no se dispone de instalador, descarga y descomprime la [http://code.google.com/p/msapy/downloads/list �ltima versi�n] disponible de la aplicaci�n.
 * Haz doble clic sobre el archivo "MSA.py" que se encunetra en el directorio "msa/".

== Estudio de una viga de dos vanos ==

Aunque esta aplicaci�n a�n se encuentra en fases tempranas de desarrollo, a continuaci�n, se muestra un ejemplo en el que se estudia una viga simple de dos vanos.

[http://lh5.ggpht.com/_OQVfrwwtV00/Sl-4mSvkeBI/AAAAAAAAALU/conExZ1ls-g/gui.png]

=== Definici�n de la estructura ===

Para definir la estructura se utiliza la plantilla "template.xls" desde EXCEL o CALC y se guardan los datos en el archivo "input.csv" como valores separados por punto y coma.

[http://lh6.ggpht.com/_OQVfrwwtV00/SlH49-N5U-I/AAAAAAAAAKo/aoBEHxIRF-s/beam.png]

En la columna "Restraints" se especifica el tipo de nudo (nudo r�gido (rj) o articulado (hj)) o el tipo de apoyo (empotramiento (fs), articulado (hs) o rodillo (rs)).

=== Resultados ===

[http://lh4.ggpht.com/_OQVfrwwtV00/SlH497HvPMI/AAAAAAAAAKs/WgXoN1KS3v0/s640/beam-sch.png]

[http://lh5.ggpht.com/_OQVfrwwtV00/SlH4-IerEnI/AAAAAAAAAKw/v3Fy_6mLRZs/s640/beam-N.png]

[http://lh6.ggpht.com/_OQVfrwwtV00/SlH4-BPIakI/AAAAAAAAAK0/-0OrmM0YGLw/s640/beam-V.png]

[http://lh3.ggpht.com/_OQVfrwwtV00/SlH4-VOwPpI/AAAAAAAAAK4/xW6kWIMQnJg/s640/beam-M.png]

== Planifaci�n y Versiones ==

|| ~~ Versi�n 0.1: Implementaci�n del m�todo de la rigidez ~~ ||

 * v 0.1.0 (2009-06-15): Implementaci�n del m�todo matricial.
 * v 0.1.1 (2009-06-21): Correcci�n de errores.

|| ~~ Versi�n 0.2: Generaci�n del esquema estructural ~~ ||

 * v 0.2.0 (2009-06-23): Generaci�n del esquema estructural.
 * v 0.2.1 (2009-06-24): Correcci�n de errores.

|| ~~ Versi�n 0.3: Generaci�n de los diagramas de esfuerzos ~~ ||

 * v 0.3.0 (2009-06-30): Generaci�n de los diagramas de esfuerzos.
 * v 0.3.1 (2009-07-06): Correcci�n de errores.
 * v 0.3.5 (2009-07-16): Interfaz gr�fica de usuario.
 * v 0.3.6 (2009-08-11): Correcci�n de errores.
 * v 0.3.7 (2009-09-17): Generaci�n del informe de resultados.

|| Versi�n 0.4: Comprobaci�n resistente ||
|| Versi�n 0.5: Refactorizaci�n ||
|| Versi�n 0.6: Generaci�n de hip�tesis de carga ||
|| Versi�n 0.7: Comprobaci�n a pandeo ||
